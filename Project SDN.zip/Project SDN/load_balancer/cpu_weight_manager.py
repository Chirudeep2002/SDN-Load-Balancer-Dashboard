from registry import registry
import random

def calc_cpu_weight_list():
    wl = []
    for server, info in registry.items():
        cpu = random.randint(10, 90)
        weight = info["weight"]
        adjusted = max(1, int(weight * (100 - cpu) / 100))
        wl.extend([server] * adjusted)
    return wl
