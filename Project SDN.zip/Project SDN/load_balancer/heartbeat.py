import time
from health_manager import check_health, auto_restart_dead

while True:
    check_health()
    auto_restart_dead()
    time.sleep(3)
