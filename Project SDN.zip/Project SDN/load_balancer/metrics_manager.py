import json, time, os
from registry import registry

# =============================================
# SAFE ABSOLUTE PATH HANDLING
# =============================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))      # SDN Project/load_balancer
PROJECT_ROOT = os.path.dirname(BASE_DIR)                   # SDN Project root

METRICS_FILE = os.path.join(PROJECT_ROOT, "metrics.json")  # Correct file for dashboard & LB
LOG_FILE = os.path.join(PROJECT_ROOT, "lb.log")

# =============================================
# DEFAULT METRICS STRUCTURE
# =============================================
default_metrics = {
    "timestamps": [],
    "latency": [],
    "server_used": [],
    "req_count": {},
    "throughput": {},
    "servers": []
}

# =============================================
# ENSURE metrics.json EXISTS
# =============================================
if (not os.path.exists(METRICS_FILE)) or os.path.getsize(METRICS_FILE) == 0:
    with open(METRICS_FILE, "w") as f:
        json.dump(default_metrics, f, indent=2)

# =============================================
# LOAD EXISTING METRICS
# =============================================
try:
    with open(METRICS_FILE) as f:
        metrics = json.load(f)
except:
    metrics = default_metrics.copy()


# =============================================
# LOGGING FUNCTION
# =============================================
def log_event(text):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] {text}\n")


# =============================================
# UPDATE METRICS
# =============================================
def update_metrics(server, latency):
    now = time.time()

    metrics["timestamps"].append(now)
    metrics["latency"].append(latency)
    metrics["server_used"].append(server)

    metrics["req_count"][server] = metrics["req_count"].get(server, 0) + 1

    metrics["throughput"][server] = round(
        metrics["req_count"][server] / max(1, (now - metrics["timestamps"][0])),
        3
    )

    # ALWAYS keep active server list updated
    metrics["servers"] = list(registry.keys())

    save()


# =============================================
# SAVE METRICS TO DISK
# =============================================
def save():
    # Debug print to verify real path
    print("💾 Saving metrics to:", METRICS_FILE)

    metrics["servers"] = list(registry.keys())
    with open(METRICS_FILE, "w") as f:
        json.dump(metrics, f, indent=2)
