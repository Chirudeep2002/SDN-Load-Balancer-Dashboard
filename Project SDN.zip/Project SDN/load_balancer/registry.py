registry = {
    "http://127.0.0.1:5001": {"weight": 3, "status": "alive"},
    "http://127.0.0.1:5002": {"weight": 2, "status": "alive"},
    "http://127.0.0.1:5003": {"weight": 1, "status": "alive"},
}
