from flask import Flask, jsonify
import random, time

class SDNServer:
    def __init__(self, name, port):
        self.app = Flask(name)
        self.name = name
        self.port = port

        @self.app.route("/")
        def index():
            delay = round(random.uniform(0.1, 1.0), 3)
            cpu = random.randint(10, 95)
            mem = random.randint(10, 95)
            time.sleep(delay)

            return jsonify({
                "server": self.name,
                "port": self.port,
                "delay": delay,
                "cpu": cpu,
                "memory": mem
            })

        @self.app.route("/heartbeat")
        def heartbeat():
            return jsonify({"status": "alive", "server": self.name})

    def run(self):
        self.app.run(port=self.port)
